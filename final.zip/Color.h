//
// Created by Dwight J. Browne on 11/4/19.
//

#ifndef TESTBED2_COLOR_H
#define TESTBED2_COLOR_H


class Color {
public:
    float r;
    float g;
    float b;
    float a;

    Color();

    Color(float r1, float g1, float b1, float a1);

    ~Color();
};


#endif //TESTBED2_COLOR_H
