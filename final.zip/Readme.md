
********************************************************************
********************************************************************
*  CSCI 5229  - Schreuder Computer Graphics
*  Dwight Browne
* Final project
*  Key Bindings:
* Arrows change view angle
* ESC Exit
* home_key or h:  set Azimuth and elevation to 0.
* w move camera forward.
* a move camera left.
* s move camera back.
* d move camera right.
* SPACE stop Light animation.

* \+ increase scaling factor.
* \- decrease scaling factor.
* y rotate sphere by y
* z rotate sphere by z
* p toggle perspective
* l  Toggle lighting   Spotlight shader is currently broken
* O  Toggle Polygon mode
* T  Toggle Texture









* run final
Total time 60 hours due to several false starts and pernicious bugs.  


*  TODOS:

1. Change initial viewing angle
2. Add shaders
3. Fix some coding issues.  
4.
********************************************************************
********************************************************************
